﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","fi",{title:"Paikkamerkin ominaisuudet",toolbar:"Luo paikkamerkki",name:"Paikkamerkin nimi",invalidName:"Paikkamerkki ei voi olla tyhjä eikä sisältää seuraavia merkkejä: [, ], <, >",pathName:"paikkamerkki"});
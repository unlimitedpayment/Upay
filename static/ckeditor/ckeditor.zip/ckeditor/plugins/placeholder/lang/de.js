﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","de",{title:"Platzhaltereinstellungen",toolbar:"Platzhalter",name:"Platzhaltername",invalidName:"Der Platzhalter darf nicht leer sein und folgende Zeichen nicht enthalten: [, ], <, >",pathName:"Platzhalter"});
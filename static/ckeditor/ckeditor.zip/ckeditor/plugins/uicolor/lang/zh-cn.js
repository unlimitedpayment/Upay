﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","zh-cn",{title:"用户界面颜色选择器",preview:"即时预览",config:"粘贴此字符串到您的 config.js 文件",predefined:"预定义颜色集"});
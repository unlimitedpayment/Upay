﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","fa",{title:"انتخاب رنگ رابط کاربری",preview:"پیش‌نمایش زنده",config:"این رشته را در پروندهٔ config.js خود رونوشت کنید.",predefined:"مجموعه رنگ از پیش تعریف شده"});
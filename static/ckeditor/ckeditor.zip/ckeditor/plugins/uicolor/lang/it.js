﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","it",{title:"Selettore Colore UI",preview:"Anteprima Live",config:"Incolla questa stringa nel tuo file config.js",predefined:"Set di colori predefiniti"});
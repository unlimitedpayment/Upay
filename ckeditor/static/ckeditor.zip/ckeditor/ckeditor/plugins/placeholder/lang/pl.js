﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","pl",{title:"Właściwości wypełniacza",toolbar:"Utwórz wypełniacz",name:"Nazwa wypełniacza",invalidName:"Wypełniacz nie może być pusty ani nie może zawierać żadnego z następujących znaków: [, ], < oraz >",pathName:"wypełniacz"});